# -*- coding: utf-8 -*-
"""
Created on Sat Apr 23 18:07:15 2022

@author: physlab
"""

import numpy as np
import matplotlib
import matplotlib.pyplot as plt

def CleanData(data):
    
    bkgnd = np.loadtxt('bkgd_3detectors.txt')
    bkgnd = np.sum(bkgnd, axis = 0)/len(bkgnd)
    
    for file in data:
        counter = 0
        for row in file:
            row[4] = row[4] - row[0]*row[1]*20*10**-9 #AB
            row[5] = row[5] - row[0]*row[2]*20*10**-9 #AB'
            row[6] = row[6] - row[3]*row[1]*20*10**-9 #A'B
            row[7] = row[7] - row[3]*row[2]*20*10**-9 #A'B'
            file[counter] = row - bkgnd
            counter += 1
            
    return data

files = ['0.txt', '22.5.txt', '45.txt', '67.5.txt', '90.txt']

data = []

for i in files:
    data.append(np.loadtxt(i))
    
data = CleanData(data)
    
coincidences = []

for i in data:
    coincidences.append(i[:,4])

steps = [i for i in range(-1500,1500,20)]



plt.rcParams.update({
 "lines.color": "0.5",
 "patch.edgecolor": "0.5",
 "text.color": "0.1",
 "axes.facecolor": "0.9",
 "axes.edgecolor": "0.5",
 "axes.labelcolor": "0.1",
 "xtick.color": "black",
 "ytick.color": "black",
 "grid.color": "lightgray",
 "figure.facecolor": "1",
 "figure.edgecolor": "1",
 "savefig.facecolor": "1",
 "savefig.edgecolor": "1"})

plt.figure()

ax = plt.axes()

ax.plot(steps, coincidences[0], label = '0', color = '#E64BFF', marker = '1')
ax.plot(steps, coincidences[1], label = '22.5', color = '#2B9EE5', marker = '.')
ax.plot(steps, coincidences[2], label = '45', color = '#E5BA2A', marker = 's')
ax.plot(steps, coincidences[3], label = '67.5', color = '#E52B2B', marker = '+')
ax.plot(steps, coincidences[4], label = '90', color = '#29BC14', marker = '^')

ax.set_title("Interference Fringes for different polarizer angles", size=19)
ax.set_xlabel("Piezoelectric motor steps", fontsize=17)
ax.set_ylabel("Single photon counts (1/s)", size=17)

ax.xaxis.set_tick_params(which = 'major', size = 7)
ax.yaxis.set_tick_params(which = 'major', size = 7)

ax.tick_params(axis = 'x', labelsize = 13)
ax.tick_params(axis = 'y', labelsize = 13)
    
ax.legend()

plt.show()