# -*- coding: utf-8 -*-
"""
Created on Thu Jun  9 12:56:53 2022

@author: physlab
"""

import numpy as np
from matplotlib import pyplot as plt

a_aligned = np.loadtxt("aligned_coincidence.txt")[0]
a_unaligned = np.loadtxt("unaligned_coincidence.txt")[0]

b_aligned = np.loadtxt("aligned_coincidence.txt")[1]
b_unaligned = np.loadtxt("unaligned_coincidence.txt")[1]

ab_aligned = np.loadtxt("aligned_coincidence.txt")[2]
ab_unaligned = np.loadtxt("unaligned_coincidence.txt")[2]

aberr_aligned_aligned = np.loadtxt("aligned_coincidence.txt")[3]
aberr_unaligned_unaligned = np.loadtxt("unaligned_coincidence.txt")[3]


degs = []

for i in range(0, 181, 5):
    degs.append(i)
    
plt.rcParams.update({
 "lines.color": "0.5",
 "patch.edgecolor": "0.5",
 "text.color": "0.1",
 "axes.facecolor": "0.9",
 "axes.edgecolor": "0.5",
 "axes.labelcolor": "0.1",
 "xtick.color": "black",
 "ytick.color": "black",
 "grid.color": "lightgray",
 "figure.facecolor": "1",
 "figure.edgecolor": "1",
 "savefig.facecolor": "1",
 "savefig.edgecolor": "1"})

plt.plot(degs, a_aligned, marker = "o", label = "A's counts")
plt.plot(degs, b_aligned, marker = "s", label = "B's counts")

plt.legend()
plt.title("Single detector counts after alignment")
plt.xlabel(r"Pump beam HWP angle ($^\circ$)")
plt.ylabel("Counts")
plt.ylim(0,120000)
    
# plt.plot(degs, ab_aligned, marker = "o", label = "Aligned")
# plt.plot(degs, ab_unaligned, marker = "s", label = "Unaligned")

# plt.legend()
# plt.title("Coincidence counts vs pump HWP angle")
# plt.xlabel(r"Pump beam HWP angle ($^\circ$)")
# plt.ylabel("Coincidence counts")

plt.show()