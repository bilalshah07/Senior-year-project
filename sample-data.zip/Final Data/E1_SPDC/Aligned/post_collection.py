# -*- coding: utf-8 -*-
"""
Created on Thu Jun  9 12:15:45 2022

@author: physlab
"""

import numpy as np
from matplotlib import pyplot as plt


files = []

for i in range(37):
    files.append("data"+str(i)+".txt")

a = []
b = []
ab = []

for i in files:
    a.append(np.loadtxt(i)[:,0])
    b.append(np.loadtxt(i)[:,1])
    ab.append(np.loadtxt(i)[:,4])

a = np.array(a)
b = np.array(b)
ab = np.array(ab)
    
a_avg = np.sum(a, axis = 1)/10
b_avg = np.sum(b, axis = 1)/10
ab_avg = np.sum(ab, axis = 1)/10

ab_error = []

for i in ab:
    ab_error.append(np.std(i)/np.sqrt(10))

ab_error = np.array(ab_error)
print(len(ab_error))

acc = a_avg*b_avg*20*10**-9

ab_corrected = ab_avg - acc
    
np.savetxt("aligned_coincidence.txt", [a_avg, b_avg, ab_corrected, ab_error])
    

    