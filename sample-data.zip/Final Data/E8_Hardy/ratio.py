# -*- coding: utf-8 -*-
"""
Created on Wed Jul  6 17:16:08 2022

@author: physlab
"""
# This code determined the ratio of counts AB:AB' desired for the requierd state.

import numpy as np

data = np.loadtxt('ratio.txt')

ratio = np.sum(data[:,4])/np.sum(data[:,7])

print(ratio)