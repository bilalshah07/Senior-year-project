# -*- coding: utf-8 -*-
"""
Created on Wed Jul  6 17:48:30 2022

@author: physlab
"""
import numpy as np
import scipy.stats as st

def AvgCounts(data):
    
    hh = (np.average(data[:, 7]), st.sem(data[:, 7]))
    hv = (np.average(data[:, 6]), st.sem(data[:, 6]))
    vh = (np.average(data[:, 5]), st.sem(data[:, 5]))
    vv = (np.average(data[:, 4]), st.sem(data[:, 4]))
    
    return {'hh': hh, 'hv': hv, 'vh': vh, "vv": vv}

def Probs(data):
    pr_hh = data['hh'][0]/(data['hh'][0]+data['hv'][0]+data['vh'][0]+data['vv'][0])
    pr_hv = data['hv'][0]/(data['hh'][0]+data['hv'][0]+data['vh'][0]+data['vv'][0])
    pr_vh = data['vh'][0]/(data['hh'][0]+data['hv'][0]+data['vh'][0]+data['vv'][0])
    pr_vv = data['vv'][0]/(data['hh'][0]+data['hv'][0]+data['vh'][0]+data['vv'][0])
    
    den = (data['hh'][0]+data['hv'][0]+data['vh'][0]+data['vv'][0])
    err_den = np.sqrt((data['hh'][1]**2+data['hv'][1]**2+data['vh'][1]**2+data['vv'][1]**2))
    
    err_pr_hh = pr_hh * np.sqrt((data['hh'][1]/data['hh'][0])**2 + (err_den/den)**2)
    err_pr_hv = pr_hv * np.sqrt((data['hv'][1]/data['hv'][0])**2 + (err_den/den)**2)
    err_pr_vh = pr_vh * np.sqrt((data['vh'][1]/data['vh'][0])**2 + (err_den/den)**2)
    err_pr_vv = pr_vv * np.sqrt((data['vv'][1]/data['vv'][0])**2 + (err_den/den)**2)
    
    return {'hh':(pr_hh,err_pr_hh), 'hv':(pr_hv,err_pr_hv), 'vh':(pr_vh,err_pr_vh), 'vv':(pr_vv,err_pr_vv)}

def CleanData(data):
    
    for file in data:
        for row in data[file]:
            row[4] = row[4] - row[0]*row[1]*20*10**-9 #AB
            row[5] = row[5] - row[0]*row[2]*20*10**-9 #AB'
            row[6] = row[6] - row[3]*row[1]*20*10**-9 #A'B
            row[7] = row[7] - row[3]*row[2]*20*10**-9 #A'B'
            
    return data

#importing data 

files = ['-a,a', '-ap,-b', 'b,ap', 'b,-b']

data = {}

for i in files:
    data[i] = np.loadtxt(i+'.txt')
    
data = CleanData(data)
    
counts = {}

for i in data:
    counts[i] = AvgCounts(data[i])
    
probs = {}

for i in counts:
    probs[i] = Probs(counts[i])
    

H = probs['b,-b']['hh'][0] - probs['-a,a']['hh'][0] - probs['-ap,-b']['hh'][0] -probs['b,ap']['hh'][0]


# error determination

err_H = np.sqrt(probs['b,-b']['hh'][1]**2 + probs['-a,a']['hh'][1]**2 + probs['-ap,-b']['hh'][1]**2 +probs['b,ap']['hh'][1]**2)

print('H = ', round(H,4), '+-', round(err_H,4))

#confidence interval

conf = H/err_H

print('Confidence interval:', round(conf-0.5))

print('b, -b', round(probs['b,-b']['hh'][0], 4), '+-', round(probs['b,-b']['hh'][1], 4 ))

print('b, ap', round(probs['b,ap']['hh'][0],4) , '+-', round(probs['b,ap']['hh'][1], 4 ))

print('-ap, -b', round(probs['-ap,-b']['hh'][0],4) , '+-', round(probs['-ap,-b']['hh'][1], 4 ))

print('-a, a', round(probs['-a,a']['hh'][0],4) , '+-', round(probs['-a,a']['hh'][1], 4 ))
    
    

