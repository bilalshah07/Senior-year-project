# -*- coding: utf-8 -*-
"""
Created on Fri Jun 10 18:24:08 2022

@author: physlab
"""

import numpy as np
import matplotlib.pyplot as plt

def g2(na, nab, nabp, nabbp):
    return (na*nabbp)/(nab*nabp)

def CleanData(data):
    
    bkgnd = np.loadtxt('bkgd_3detectors.txt')
    bkgnd = np.sum(bkgnd, axis = 0)/len(bkgnd)
    
    for file in data:
        counter = 0
        for row in file:
            row[4] = row[4] - row[0]*row[1]*20*10**-9 #AB
            row[5] = row[5] - row[0]*row[2]*20*10**-9 #AB'
            row[6] = row[6] - row[3]*row[1]*20*10**-9 #A'B
            row[7] = row[7] - row[3]*row[2]*20*10**-9 #A'B'
            file[counter] = row - bkgnd
            counter += 1
            
    return data

data = []
delay = []

for n in range(-60,61,2):
    delay.append(n)
    data.append(np.loadtxt('data'+str(n)+'.txt'))
    
data = np.array(data)
    
g2_vals = []
g2_mean = []
g2_err = []
    
for i in data:
    
    for j in i:
        
        a = j[0]
        ab = j[4]
        abp = j[5]
        abbp = j[8]

        g2_vals.append(g2(a,ab,abp,abbp))

    g2_vals = np.array(g2_vals)
    g2_err.append(np.std(g2_vals)/np.sqrt(20))
    g2_mean.append(np.mean(g2_vals))
    g2_vals=[]
        
    
set1 = np.array(g2_mean[0:27])
set2 = np.array(g2_mean[35:])
set3 = np.array(g2_mean[27:34])

avg_line1 = [np.mean(set1)]*27
avg_line2 = [np.mean(set2)]*26
avg_line3 = [np.mean(set3)]*7

range1 = [i for i in range(-60, -6, 2)]
range2 = [i for i in range(10, 61, 2)]
range3 = [i for i in range(-6, 8, 2)]

plt.rcParams.update({
 "lines.color": "0.5",
 "patch.edgecolor": "0.5",
 "text.color": "0.1",
 "axes.facecolor": "0.9",
 "axes.edgecolor": "0.5",
 "axes.labelcolor": "0.1",
 "xtick.color": "black",
 "ytick.color": "black",
 "grid.color": "lightgray",
 "figure.facecolor": "1",
 "figure.edgecolor": "1",
 "savefig.facecolor": "1",
 "savefig.edgecolor": "1"})


plt.title(r'Delay vs $g^{(2)}(\tau)$')
plt.xlabel("Delay (s)")
plt.ylabel(r"$g^{(2)}(\tau)$")

plt.errorbar(delay, g2_mean, fmt = ".", yerr = g2_err)
plt.plot(range1, avg_line1, 'orange', range2, avg_line2, 'orange', range3, avg_line3, 'orange')
plt.scatter(delay, g2_mean, color = 'lightsteelblue')


plt.show()



