# -*- coding: utf-8 -*-
"""
Created on Fri Jun 10 15:22:01 2022

@author: physlab
"""

import numpy as np
from matplotlib import pyplot as plt

def g2(na, nab, nabp, nabbp):
    return (na*nabbp)/(nab*nabp)

data = []
data.append(np.loadtxt('120s.txt'))
data.append(np.loadtxt('600s.txt'))
    
bkgd_counts = np.loadtxt("bkgd.txt")
bkgd_counts = np.sum(bkgd_counts, axis = 0)/20 

g2_val_list = []
g2_vals = []

for i in data:
    for j in i:
        a = j[0] - bkgd_counts[0]
        ab = j[4] - (j[0]*j[1]*20*10**-9)
        abp = j[5] - (j[0]*j[2]*20*10**-9)
        abbp = j[8]
        
        g2_vals.append(g2(a, ab, abp, abbp))
    
    g2_val_list.append(g2_vals)
    g2_vals = []


for i in range(len(g2_val_list)):
    mean_g2 = np.mean(g2_val_list[i])
    std_err_g2 = np.std(g2_val_list[i])/np.sqrt(121+i*480)
    print('Mean:', mean_g2, 'Error:', std_err_g2, 'Confidence:', (1-mean_g2)/std_err_g2)


    
