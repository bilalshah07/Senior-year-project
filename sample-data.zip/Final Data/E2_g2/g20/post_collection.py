# -*- coding: utf-8 -*-
"""
Created on Fri Jun 10 15:22:01 2022

@author: physlab
"""

import numpy as np
from matplotlib import pyplot as plt

def g2(na, nab, nabp, nabbp):
    return (na*nabbp)/(nab*nabp)

def g2c(nb, nbp):
    neu = np.mean(nb*nbp)
    den = np.mean(nb)*np.mean(nbp)    
    return neu/den

data = []

for i in range(37):
    data.append(np.loadtxt("data"+str(i)+".txt"))
data = np.array(data)
    
bkgd_counts = np.loadtxt("bkgd.txt")
bkgd_counts = np.sum(bkgd_counts, axis = 0)/20 

g2c_vals = []
for i in data:
    b = i[:,1] - bkgd_counts[1]
    bp = i[:,2] - bkgd_counts[2]
    
    g2c_vals.append(g2c(b, bp))
g2c_vals.pop()
    

data_avg = []
for i in range(37):
    data_avg.append(np.sum(data[i], axis = 0)/20)
data_avg = np.array(data_avg)
    
# print(bkgd_counts)

g2_vals = []

for i in data_avg:
    
    a = i[0] - bkgd_counts[0]
    ab = i[4] - (i[0]*i[1]*20*10**-9)
    abp = i[5] - (i[0]*i[2]*20*10**-9)
    abbp = i[8]
    
    g2_vals.append(g2(a, ab, abp, abbp))


g2_vals.pop()
g2_vals[0] = 0
g2_vals[18] = 0

mean_g2 = np.mean(g2_vals)
std_err_g2 = np.std(g2_vals)/np.sqrt(34)

degs = [i for i in range(0, 180, 5)]

mean = [mean_g2]*36
meanc = [1]*36

plt.rcParams.update({
 "lines.color": "0.5",
 "patch.edgecolor": "0.5",
 "text.color": "0.1",
 "axes.facecolor": "0.9",
 "axes.edgecolor": "0.5",
 "axes.labelcolor": "0.1",
 "xtick.color": "black",
 "ytick.color": "black",
 "grid.color": "lightgray",
 "figure.facecolor": "1",
 "figure.edgecolor": "1",
 "savefig.facecolor": "1",
 "savefig.edgecolor": "1"})

plt.scatter(degs, g2_vals, label = 'Quantum')
plt.scatter(degs, g2c_vals, marker = 's',color='tab:green', label = 'Classical')
plt.plot(degs, mean, color='red')
plt.plot(degs,meanc, color='red')

plt.title(r'$g^{(2)}(0)$ vs HWP angle')
plt.xlabel(r"HWP angle $(^\circ$)")
plt.ylabel(r'$g^{(2)}(0)$')
plt.legend()

print(std_err_g2, mean_g2)
    
    
