# -*- coding: utf-8 -*-
"""
Created on Sun Jan 23 16:46:05 2022

@author: physlab
"""

import numpy as np
from scipy import linalg

def purity(rho):
   return np.trace(rho@rho)

def CleanData(data):
    
    bkgnd = np.loadtxt('bkgd_4detectors.txt')
    bkgnd = np.sum(bkgnd, axis = 0)/len(bkgnd)
    
    for file in data:
        counter = 0
        for row in file:
            row[4] = row[4] - row[0]*row[1]*20*10**-9 #AB
            row[5] = row[5] - row[0]*row[2]*20*10**-9 #AB'
            row[6] = row[6] - row[3]*row[1]*20*10**-9 #A'B
            row[7] = row[7] - row[3]*row[2]*20*10**-9 #A'B'
            # file[counter] = row - bkgnd
            counter += 1
            
    return data

def fidelity(expected,measurement):
    trace = np.trace(linalg.sqrtm(linalg.sqrtm(expected) @ measurement @ linalg.sqrtm(expected)))
    return trace**2

def concurrence(rho):
    
    #spin flip matrix for concurrence

    Z = np.zeros(16).reshape(4,4)
    Z[0,3] = -1
    Z[1,2] = 1
    Z[2,1] = 1
    Z[3,0] = -1
    
    matrix = rho@Z@np.transpose(rho)@Z
    
    eig1, eig2, eig3, eig4 = np.linalg.eigvals(matrix)
    
    return (np.sqrt(eig1) - np.sqrt(eig2) - np.sqrt(eig3) - np.sqrt(eig4))

files = ['HH.txt', 'HD.txt', 'HR.txt', 'DH.txt', 'DD.txt', 'DR.txt', 'RH.txt', 'RD.txt', 'RR.txt']

data = []

# Extracting data
for i in files:
    data.append(np.loadtxt(i))

data = np.array(data)

# data = CleanData(data)

# Taking average of data
data_avg = []
for i in range(len(data)):
    data_avg.append(np.sum(data[i], axis = 0)/len(data[0]))
data_avg = np.array(data_avg)


order = ["A", "B", "BP", "AP", "VV", "VH", "HV", "HH", "ABBP"]

# for i in range(len(order)):
#     print(order[i], i, files[i])
    

np.set_printoptions(precision=0)
for i in range(len(files)):
    print(files[i], np.flip(data_avg[i][4:8]))

hh = data_avg[0][7]/(data_avg[0][4]+data_avg[0][5]+data_avg[0][6]+data_avg[0][7])
hv = data_avg[0][6]/(data_avg[0][4]+data_avg[0][5]+data_avg[0][6]+data_avg[0][7])
vh = data_avg[0][5]/(data_avg[0][4]+data_avg[0][5]+data_avg[0][6]+data_avg[0][7])
vv = data_avg[0][4]/(data_avg[0][4]+data_avg[0][5]+data_avg[0][6]+data_avg[0][7])

hd = data_avg[1][7]/(data_avg[1][4]+data_avg[1][5]+data_avg[1][6]+data_avg[1][7])
ha = data_avg[1][6]/(data_avg[1][4]+data_avg[1][5]+data_avg[1][6]+data_avg[1][7])
vd = data_avg[1][5]/(data_avg[1][4]+data_avg[1][5]+data_avg[1][6]+data_avg[1][7])
va = data_avg[1][4]/(data_avg[1][4]+data_avg[1][5]+data_avg[1][6]+data_avg[1][7])

hl = data_avg[2][7]/(data_avg[2][4]+data_avg[2][5]+data_avg[2][6]+data_avg[2][7])
hr = data_avg[2][6]/(data_avg[2][4]+data_avg[2][5]+data_avg[2][6]+data_avg[2][7])
vl = data_avg[2][5]/(data_avg[2][4]+data_avg[2][5]+data_avg[2][6]+data_avg[2][7])
vr = data_avg[2][4]/(data_avg[2][4]+data_avg[2][5]+data_avg[2][6]+data_avg[2][7])

dh = data_avg[3][7]/(data_avg[3][4]+data_avg[3][5]+data_avg[3][6]+data_avg[3][7])
dv = data_avg[3][6]/(data_avg[3][4]+data_avg[3][5]+data_avg[3][6]+data_avg[3][7])
ah = data_avg[3][5]/(data_avg[3][4]+data_avg[3][5]+data_avg[3][6]+data_avg[3][7])
av = data_avg[3][4]/(data_avg[3][4]+data_avg[3][5]+data_avg[3][6]+data_avg[3][7])

dd = data_avg[4][7]/(data_avg[4][4]+data_avg[4][5]+data_avg[4][6]+data_avg[4][7])
da = data_avg[4][6]/(data_avg[4][4]+data_avg[4][5]+data_avg[4][6]+data_avg[4][7])
ad = data_avg[4][5]/(data_avg[4][4]+data_avg[4][5]+data_avg[4][6]+data_avg[4][7])
aa = data_avg[4][4]/(data_avg[4][4]+data_avg[4][5]+data_avg[4][6]+data_avg[4][7])

dl = data_avg[5][7]/(data_avg[5][4]+data_avg[5][5]+data_avg[5][6]+data_avg[5][7])
dr = data_avg[5][6]/(data_avg[5][4]+data_avg[5][5]+data_avg[5][6]+data_avg[5][7])
al = data_avg[5][5]/(data_avg[5][4]+data_avg[5][5]+data_avg[5][6]+data_avg[5][7])
ar = data_avg[5][4]/(data_avg[5][4]+data_avg[5][5]+data_avg[5][6]+data_avg[5][7])

lh = data_avg[6][7]/(data_avg[6][4]+data_avg[6][5]+data_avg[6][6]+data_avg[6][7])
lv = data_avg[6][6]/(data_avg[6][4]+data_avg[6][5]+data_avg[6][6]+data_avg[6][7])
rh = data_avg[6][5]/(data_avg[6][4]+data_avg[6][5]+data_avg[6][6]+data_avg[6][7])
rv = data_avg[6][4]/(data_avg[6][4]+data_avg[6][5]+data_avg[6][6]+data_avg[6][7])

ld = data_avg[7][7]/(data_avg[7][4]+data_avg[7][5]+data_avg[7][6]+data_avg[7][7])
la = data_avg[7][6]/(data_avg[7][4]+data_avg[7][5]+data_avg[7][6]+data_avg[7][7])
rd = data_avg[7][5]/(data_avg[7][4]+data_avg[7][5]+data_avg[7][6]+data_avg[7][7])
ra = data_avg[7][4]/(data_avg[7][4]+data_avg[7][5]+data_avg[7][6]+data_avg[7][7])

ll = data_avg[8][7]/(data_avg[8][4]+data_avg[8][5]+data_avg[8][6]+data_avg[8][7])
lr = data_avg[8][6]/(data_avg[8][4]+data_avg[8][5]+data_avg[8][6]+data_avg[8][7])
rl = data_avg[8][5]/(data_avg[8][4]+data_avg[8][5]+data_avg[8][6]+data_avg[8][7])
rr = data_avg[8][4]/(data_avg[8][4]+data_avg[8][5]+data_avg[8][6]+data_avg[8][7])


np.set_printoptions(precision=1)

# counter = 0
# for i in data_avg:
#     print(files[counter], i[4], i[5], i[6], i[7], '\n')
#     counter += 1

s00 = hh + hv + vh + vv
s01 = hd - ha + vd - va
s02 = hl - hr + vl - vr
s03 = hh - hv + hv - vv
s10 = dh + dv - ah - av
s11 = dd - da - ad + aa
s12 = dl - dr - al + ar
s13 = dh - dv - ah + av
s20 = lh + lv - rh - rv
s21 = ld - la - rd + ra
s22 = ll - lr - rl + rr
s23 = lh - lv - rh + rv
s30 = hh + hv - vh - vv
s31 = hd - ha - vd + va
s32 = hl - hr - vl + vr
s33 = hh - hv - vh + vv

# Pauli matrices
o0 = np.array([[1+0j,0+0j],[0+0j,1+0j]])
o1 = np.array([[0+0j,1+0j],[1+0j,0+0j]])
o2= np.array([[0+0j,-1j],[1j,0+0j]])
o3 = np.array([[1+0j,0+0j],[0+0j,-1+0j]])

s = np.array([[s00, s01, s02, s03], [s10, s11, s12, s13], [s20, s21, s22, s23], [s30, s31, s32, s33]])
o = [o0, o1, o2, o3]

rho = np.zeros((2,2,2,2))*0j

for i in range(4):
    for j in range(4):
        rho += s[i][j]*np.tensordot(o[i], o[j], axes = 0)
        
rho = rho/4

print(rho[0][0][0], rho[0][1][0], '\n', rho[0][0][1], rho[0][1][1], '\n', rho[1][0][0], rho[1][1][0], '\n', rho[1][0][1], rho[1][1][1])
# #Bell state predicted density matrix

# exp_rho_bell = np.zeros(16).reshape(4,4)
# exp_rho_bell[0,0] = 0.5
# exp_rho_bell[0,3] = 0.5
# exp_rho_bell[3,0] = 0.5
# exp_rho_bell[3,3] = 0.5

# #bell state measured density matrix

# rho_bell = np.array([0.497 + 0j, 0.009 + 0.020j, -0.011 + 0.023j, 0.400 - 0.053j,
#                      0.009 - 0.020j, 0.008 + 0j, 0.011 + 0.023j, 0.003 - 0.032j,
#                      -0.011 - 0.023j, 0.011 - 0.023j, 0.008 + 0j, 0.001 - 0.027j,
#                      0.400 + 0.053j, 0.003 + 0.032j, 0.001 + 0.027j, 0.487 + 0j]).reshape(4,4)

# np.set_printoptions(precision=3)
# print('Density matrix for bell state:\n', rho_bell)

# #calculating fidelity

# print('Fidelity of bell state:  %.3f' % np.real(fidelity(exp_rho_bell,rho_bell)))

# #calculating concurrence

# print('Concurrence of bell state:   %.3f' %np.real(concurrence(rho_bell)))      

# #calculating tangle

# print('Tangle of bell state:   %.3f' %(np.real(concurrence(rho_bell))**2))  

# #calculating purity 

# print('Purity of bell state:  %.3f' %np.real(purity(rho_bell))) 





