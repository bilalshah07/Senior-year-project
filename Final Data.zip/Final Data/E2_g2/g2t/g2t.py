# -*- coding: utf-8 -*-
"""
Created on Sat Jan 22 14:50:20 2022

@author: physlab
"""

# -*- coding: utf-8 -*-
"""
Created on Wed Jan 19 21:36:20 2022

@author: physlab
"""

import numpy as np
import matplotlib.pyplot as plt

def g2(data):

    nab = data[4]
    nabp = data[5]
    # na = nab + nabp
    na = data[0]
    nabbp = data[8]
    
    return((na*nabbp)/(nab*nabp))

data = []
delay = []

order = ["A", "B", "BP", "AP", "AB", "ABP", "APB", "APBP", "ABBP"]

for i in range(-60, 61, 2):
    data.append(np.loadtxt("data"+str(i)+".txt"))
    delay.append(i)
    
data = np.array(data)    

data_summed = []

for i in range(len(data)):
    data_summed.append(np.sum(data[i], axis = 0))

data_summed = np.array(data_summed)

data_avg = data_summed / 20 # broadcasting

for i in range(len(data_avg[0])):
    print(order[i], data_avg[0, i])

ab_vals = data_avg[:,4]
abp_vals = data_avg[:,5]

# print((ab_vals))
# print(abp_vals)

# plt.plot(delay, ab_vals, label = "AB")
# plt.plot(delay, abp_vals, label = "AB'")
# plt.xlabel("Delay (s)")
# plt.ylabel("Coincicendce counts")
# plt.legend()
# plt.show()

g2_vals = []
for i in range(len(data_avg)):
    g2_vals.append(g2(data_avg[-1-i]))
    
    
plt.rcParams.update({
 "lines.color": "0.5",
 "patch.edgecolor": "0.5",
 "text.color": "0.1",
 "axes.facecolor": "0.9",
 "axes.edgecolor": "0.5",
 "axes.labelcolor": "0.1",
 "xtick.color": "black",
 "ytick.color": "black",
 "grid.color": "lightgray",
 "figure.facecolor": "1",
 "figure.edgecolor": "0.1",
 "savefig.facecolor": "0.1",
 "savefig.edgecolor": "0.1"})

plt.plot(delay, g2_vals, marker = 'o')
plt.title(r'Delay vs $g^{(2)}(\tau)$')
plt.xlabel("Delay (s)")
plt.ylabel(r"Second Order Coherence $g^{(2)}(\tau)$")

# degs = [i for i in range(0, 181, 5)]

# plt.title("Second-Order Coherence for Three Detectors (Quantum Case)", fontweight = "bold")
# plt.xlabel(r"Angle of Pump Beam HWP ($^{\circ}$)", fontsize = 12)
# plt.ylabel(r"Second-order coherence $g^{(2)}(0)$", fontsize = 12)

# plt.ylim([-0.05, 0.05])

# plt.plot(degs, g2_vals, "bo", linewidth = 0, label = r"Values of $g^{(2)}(0)$")
# plt.plot(degs, [0]*37, "g", label = "0 reference line")

# plt.legend()

# plt.tight_layout()