# -*- coding: utf-8 -*-
"""
Created on Sun Jan 23 16:46:05 2022

@author: physlab
"""

import numpy as np

def CleanData(data):
    
    bkgnd = np.loadtxt('bkgd_3detectors.txt')
    bkgnd = np.sum(bkgnd, axis = 0)/len(bkgnd)
    
    for file in data:
        counter = 0
        for row in file:
            row[4] = row[4] - row[0]*row[1]*20*10**-9 #AB
            row[5] = row[5] - row[0]*row[2]*20*10**-9 #AB'
            row[6] = row[6] - row[3]*row[1]*20*10**-9 #A'B
            row[7] = row[7] - row[3]*row[2]*20*10**-9 #A'B'
            file[counter] = row - bkgnd
            counter += 1
            
    return data

def prob_ab(data):
    return data[5]/(data[4]+data[5])
    
# Extracting data
data_hv = np.loadtxt("hv.txt")
data_da = np.loadtxt("da.txt")
data_lr = np.loadtxt("lr.txt")

data = np.array([data_hv, data_da, data_lr])

data = CleanData(data)

# Taking average of data
data_hv = np.sum(data[0], axis = 0)/len(data_hv)
data_da = np.sum(data[1], axis = 0)/len(data_da)
data_lr = np.sum(data[2], axis = 0)/len(data_lr)

a = np.sqrt(prob_ab(data_hv))
b = np.sqrt(1 - prob_ab(data_hv))
phi = np.arctan( (prob_ab(data_lr)-0.5) / (prob_ab(data_da)-0.5) )


ph = prob_ab(data_hv)
pv = 1 - ph
pd = prob_ab(data_da)
pa = 1 - pd
pr = prob_ab(data_lr)
pl = 1 - pr

s0 = ph + pv
s1 = pd - pa
s2 = pl - pr
s3 = ph - pv

o0 = np.array([[1,0],[0,1]])
o1 = np.array([[0,1],[1,0]])
o2= np.array([[0,-1j],[1j,0]])
o3 = np.array([[1,0],[0,-1]])

den_op = (s0*o0 + s1*o1 + s2*o2 + s3*o3)*0.5

np.set_printoptions(precision=3)
print(den_op)

# print("A:", a, " B:", b, r" phi:", phi)

# order = ["A", "B", "BP", "AP", "AB", "ABP", "APB", "APBP", "ABBP"]

# for i in range(len(order)):
#     print(order[i], data_hv[i])
    

