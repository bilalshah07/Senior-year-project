# -*- coding: utf-8 -*-
"""
Created on Wed Jul  6 10:40:12 2022

@author: physlab
"""

import numpy as np
import scipy.stats as sp


def CleanData(data):
    
    bkgnd = np.loadtxt('bkgd_4detectors.txt')
    bkgnd = np.sum(bkgnd, axis = 0)/len(bkgnd)
    
    for file in data:
        counter = 0
        for row in file:
            row[4] = row[4] - row[0]*row[1]*20*10**-9 #AB
            row[5] = row[5] - row[0]*row[2]*20*10**-9 #AB'
            row[6] = row[6] - row[3]*row[1]*20*10**-9 #A'B
            row[7] = row[7] - row[3]*row[2]*20*10**-9 #A'B'
            file[counter] = row - bkgnd
            counter += 1
            
    return data


pola = np.loadtxt('pola.txt')
polb = np.loadtxt('polb.txt')
nopol = np.loadtxt('nopol.txt')
pol2 = np.loadtxt('22.5.txt')
pol6 = np.loadtxt('67.5.txt')

# data = [pola, polb, nopol, pol2, pol6]

# data = CleanData(data)

# pola = data[0]
# polb = data[1]
# nopol = data[2]
# pol2 = data[3]
# pol6 = data[4]

na = np.mean(pola[:, 7])
nb = np.mean(polb[:, 7])
no = np.mean(nopol[:, 7])
n2 = np.mean(pol2[:, 7])
n6 = np.mean(pol6[:, 7])

transa = (2*na)/no
transb = (2*nb)/no

delt = (abs(n6-n2)/no)-0.25

#error determination

err_na = sp.sem(pola[:, 7])

err_nb = sp.sem(polb[:, 7])

err_no = sp.sem(nopol[:, 7])

err_n2 = sp.sem(pol2[:, 7])

err_n6 = sp.sem(pol6[:, 7])


# error in transmission

err_transa = 2 * transa * np.sqrt ((err_na/na)**2 + (err_no/no)**2)

err_transb = 2 * transb * np.sqrt ((err_nb/nb)**2 + (err_no/no)**2)

print("Transmission A:", round(transa, 3), '+-', round(err_transa, 3), "\nTransmission B: ", round(transb, 3), '+-', round(err_transb, 3))

# del prediction

del_est = ((transa * transb) / (2*np.sqrt(2))) - 0.25

# error in predicted del

np.set_printoptions(precision = 3)

err_del_est = (1/(2*np.sqrt(2))) * del_est * np.sqrt((err_transa/transa)**2 + (err_transb/transb)**2)

print('Estimated del:', round(del_est, 4), '+-' , round(err_del_est, 4))

# error in measured del

nume = abs(n2 - n6)

err_nume = np.sqrt((err_n2)**2 + (err_n6)**2)

err_delt = delt * np.sqrt((err_nume/nume)**2 + (err_no/no)**2)

print('Measured del:',round(delt,5),'+-',round(err_delt,5))

# calculating confidence interval in measured value

conf = delt/err_delt

print('Confidence interval:', round(conf-0.5))

print('N2:' , round(n2), ', N6:', round(n6),', N0:', round(no) )

print('err N2', round(err_n2-0.5), 'err_N6', round(err_n6-0.5), 'err_n0', round(err_no-0.5))
