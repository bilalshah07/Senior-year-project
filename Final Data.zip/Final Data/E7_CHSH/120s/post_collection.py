# -*- coding: utf-8 -*-
"""
Created on Wed Jul  6 15:19:28 2022

@author: physlab
"""

import numpy as np
import scipy.stats as st

def CleanData(data):
    
    for file in data:
        for row in data[file]:
            row[4] = row[4] - row[0]*row[1]*20*10**-9 #AB
            row[5] = row[5] - row[0]*row[2]*20*10**-9 #AB'
            row[6] = row[6] - row[3]*row[1]*20*10**-9 #A'B
            row[7] = row[7] - row[3]*row[2]*20*10**-9 #A'B'
            
    return data

def AvgCounts(data):
    
    hh = (np.average(data[:, 7]), st.sem(data[:, 7]))
    hv = (np.average(data[:, 6]), st.sem(data[:, 6]))
    vh = (np.average(data[:, 5]), st.sem(data[:, 5]))
    vv = (np.average(data[:, 4]), st.sem(data[:, 4]))
    
    return {'hh': hh, 'hv': hv, 'vh': vh, "vv": vv}

def Probs(data):
    pr_hh = data['hh'][0]/(data['hh'][0]+data['hv'][0]+data['vh'][0]+data['vv'][0])
    pr_hv = data['hv'][0]/(data['hh'][0]+data['hv'][0]+data['vh'][0]+data['vv'][0])
    pr_vh = data['vh'][0]/(data['hh'][0]+data['hv'][0]+data['vh'][0]+data['vv'][0])
    pr_vv = data['vv'][0]/(data['hh'][0]+data['hv'][0]+data['vh'][0]+data['vv'][0])
    
    den = (data['hh'][0]+data['hv'][0]+data['vh'][0]+data['vv'][0])
    err_den = np.sqrt((data['hh'][1]**2+data['hv'][1]**2+data['vh'][1]**2+data['vv'][1]**2))
    
    err_pr_hh = pr_hh * np.sqrt((data['hh'][1]/data['hh'][0])**2 + (err_den/den)**2)
    err_pr_hv = pr_hv * np.sqrt((data['hv'][1]/data['hv'][0])**2 + (err_den/den)**2)
    err_pr_vh = pr_vh * np.sqrt((data['vh'][1]/data['vh'][0])**2 + (err_den/den)**2)
    err_pr_vv = pr_vv * np.sqrt((data['vv'][1]/data['vv'][0])**2 + (err_den/den)**2)
    
    return {'hh':(pr_hh,err_pr_hh), 'hv':(pr_hv,err_pr_hv), 'vh':(pr_vh,err_pr_vh), 'vv':(pr_vv,err_pr_vv)}

def E(probs):
    
    E = probs['hh'][0] + probs['vv'][0] - probs['vh'][0] - probs['hv'][0]
    err_E = np.sqrt(probs['hh'][1]**2 + probs['vv'][1]**2 + probs['vh'][1]**2 + probs['hv'][1]**2)
    
    return (E, err_E)    
    

files = ['ab', 'abp', 'apb', 'apbp']

data = {}

for i in files:
    data[i] = np.loadtxt(i+'.txt')
    
data = CleanData(data)
    
counts = {}

for i in data:
    counts[i] = AvgCounts(data[i])
    
probs = {}

for i in counts:
    probs[i] = Probs(counts[i])
    
E_vals = {}   
    
for i in probs:
    E_vals[i] = E(probs[i])  
    
S = E_vals['ab'][0] - E_vals['abp'][0] + E_vals['apb'][0] + E_vals['apbp'][0]
err_S = np.sqrt(E_vals['ab'][1]**2 + E_vals['abp'][1]**2 + E_vals['apb'][1]**2 + E_vals['apbp'][1]**2)

conf = (S-2)/err_S

print('S:', S, '+-' , err_S, '\nConfidence interval:', round(conf-0.5))




    
    
    
    
    